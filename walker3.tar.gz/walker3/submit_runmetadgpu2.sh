#!/bin/bash

module purge
ml gcc/11.2.0-gpu openmpi/4.1.4-gpu gromacs/2022.5-gpu

init=step3_input
mini_prefix=step4.0_minimization
equi_prefix=step4.1_equilibration
prod_prefix=step5_production
prod_step=step5

# Minimization
# In the case that there is a problem during minimization using a single precision of GROMACS, please try to use 
# a double precision of GROMACS only for the minimization step.
mpirun -np 1 gmx_mpi grompp -f ${mini_prefix}.mdp -o ${mini_prefix}.tpr -c ${init}.gro -r ${init}.gro -p topol.top -n index.ndx -maxwarn 1
mpirun -np 4 gmx_mpi mdrun -ntomp 4 -v -deffnm ${mini_prefix} 


# Equilibration
mpirun -np 1 gmx_mpi grompp -f ${equi_prefix}.mdp -o ${equi_prefix}.tpr -c ${mini_prefix}.gro -r ${init}.gro -p topol.top -n index.ndx
mpirun -np 4 gmx_mpi mdrun -ntomp 4 -v -deffnm ${equi_prefix} -cpi ${equi_prefix}.cpt -pme gpu -npme 1 -ntomp_pme 1 -pmefft gpu -notunepme -nb gpu -bonded gpu &> equilibration${SLURM_JOB_ID}.log

mpirun -np 1 gmx_mpi grompp -time 3771 -f ${prod_prefix}.mdp -o ${prod_prefix}.tpr -c ../step4.1_equilibration.gro -t /uufs/chpc.utah.edu/common/home/bidone-group3/robert/funnel_metad/24march12/SMD/bent/step5_production.trr -r ../step4.1_equilibration.gro -p topol.top -n index.ndx -maxwarn 1 &> grompp_${SLURM_JOB_ID}.log
mpirun -np 4 gmx_mpi mdrun -ntomp 4 -v -deffnm ${prod_prefix} -cpi ${prod_prefix}.cpt -maxh 72 -pme gpu -npme 1 -ntomp_pme 1 -pmefft gpu -notunepme -nb gpu -bonded gpu -plumed plumed.dat &> production_${SLURM_JOB_ID}.log

echo "... Job Finished at `date`"
