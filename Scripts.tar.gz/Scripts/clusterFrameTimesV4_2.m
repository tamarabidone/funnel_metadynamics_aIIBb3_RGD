%close all
clear
clc
% Use this for making the contact bar plot after frame extraction and vmd
% analysis
root1="C:\Users\and_r\OneDrive - University of Utah\BidoneLab\integrin\funnel_metad\24march12\funnelMetad\";
conformations = "bent_2\" ;
subfolder='cluster2';
inputfolder='BoundCTimebound1xtractCAT2.dcd.txt';
file1=[];
for k=1:length(conformations)
    y = strcat(root1,conformations{k},subfolder);
    cd(y); %move to directory
    filelist=dir(inputfolder);
    filenames={filelist.name};
    for l=(1:length(filenames))
        fid=fopen(num2str(cell2mat(filenames(l))), 'r');
        frewind(fid)
        for kik=1:3 
             tline = (fgetl(fid));
        end
        file1=horzcat(file1,tline);
    end
end
% extract all the words that have pattern *-*-A, Remove the duplicates,
allalphaResidues=unique(regexp(file1,'\w*-\w*-A','match'));
% extract all the numbers for sorting numerically
anumber = str2double(regexp(allalphaResidues, '\d+', 'match', 'once'));  %the regexp extract the first string of digits from each char array.
% sort the numbers and apply that sorting to the residue list.
[~, alphaorder] = sort(anumber, 'ascend');
sortedalpharesidues=allalphaResidues(alphaorder);

allbetaResidues=unique(regexp(file1,'\w*-\w*-B','match'));
bnumber=str2double(regexp(allbetaResidues,'\d+','match','once'));
[~,betaorder]=sort(bnumber,'ascend');
sortedbetaresidues=allbetaResidues(betaorder);

allDResidues=unique(regexp(file1,'\w*-\w*-D','match'));
Dnumber=str2double(regexp(allDResidues,'\d+','match','once'));
[~,Dorder]=sort(Dnumber,'ascend');
sortedDresidues=allDResidues(Dorder);
% frame0
%xvalues={'PHE-160-A'	'SER-161-A'	'TYR-189-A'	'TYR-190-A'	'LEU-192-A'	'ASP-224-A'	'SER-225-A'	'PHE-231-A'	'ASP-232-A' 'SER-121-B'	'TYR-122-B'	'SER-123-B'	'SER-213-B'	'ARG-214-B'	'ASN-215-B'	'ARG-216-B'	'ASP-217-B'	'ALA-218-B'	'GLU-220-B' 'MG-2001-D'}
% No Filter
xvalues={'TYR-155-A'	'VAL-156-A'	'ASN-158-A'	'ASP-159-A'	'PHE-160-A'	'SER-161-A'	'TRP-162-A'	'ASP-163-A'	'ARG-165-A'	'TYR-166-A'	'TYR-189-A'	'TYR-190-A'	'PHE-191-A'	'LEU-192-A'	'ASP-224-A'	'SER-225-A'	'SER-226-A'	'ASN-227-A'	'TYR-230-A'	'PHE-231-A'	'ASP-232-A' 'ASP-119-B'	'LEU-120-B'	'SER-121-B'	'TYR-122-B'	'SER-123-B'	'MET-124-B'	'VAL-157-B'	'TYR-166-B'	'CYS-177-B'	'MET-180-B'	'SER-213-B'	'ARG-214-B'	'ASN-215-B'	'ARG-216-B'	'ASP-217-B'	'ALA-218-B'	'PRO-219-B'	'GLU-220-B'	'THR-250-B'	'ASP-251-B'	'ALA-252-B' 'MG-2001-D'};
% 10% filter
%xvalues={'ASP-159-A'	'PHE-160-A'	'SER-161-A'	'ASP-163-A'	'TYR-189-A'	'TYR-190-A'	'LEU-192-A'	'ASP-224-A'	'SER-225-A'	'PHE-231-A' 'ASP-119-B'	'LEU-120-B'	'SER-121-B'	'TYR-122-B'	'SER-123-B'	'TYR-166-B'	'SER-213-B'	'ARG-214-B'	'ASN-215-B'	'ARG-216-B'	'ASP-217-B'	'ALA-218-B'	'GLU-220-B'	'THR-250-B'	'ASP-251-B'	'ALA-252-B' 'MG-2001-D'};
for k=1:length(conformations)
    matrix2=zeros(3,length(xvalues));
    matrix3=zeros(3,length(xvalues));
    matrix4=zeros(3,length(xvalues));
    y = strcat(root1,conformations{k},subfolder);
    cd(y); %move to directory
    filelist=dir(inputfolder);
    filenames={filelist.name};
    consplit=strsplit(conformations(k),'.');
    %consplit=strsplit(consplit1(2),'3');
    street=1;
    for l=(1:length(filenames))    
        filensplit=strsplit(cell2mat(filenames(l)),'.');
        fid=fopen(num2str(cell2mat(filenames(l))), 'r');
        frewind(fid)
        for k=1:1 
            if (k == 1)
                tline = (fgetl(fid));
                numlist=regexp(tline,'\d+','match');
                totalframes=str2num(numlist{3});
            else
                tline = (fgetl(fid));
            end
        end
        %clustername=strcat(consplit(1),", ",'top 3 populated clusters');
        clustername=strcat(consplit(1),", ",'AllBoundFrames');
        %clustername=strcat(consplit(1)," ",filensplit(2)," ",num2str(totalframes),'frames');
        tline=[sortedalpharesidues, sortedbetaresidues, sortedDresidues];
        matrix1 = zeros(3,length(tline));        
        counter=0;
        row=1;
        while ~feof(fid)
            counter=counter+1;
            dline = fgetl(fid);
            % if the fileline is >= 3 entries and it starts with a digit.
            if (length(dline) >= 3)
                if isstrprop(dline(1),'digit')
                    dline=strsplit(dline,', ');
                    % go through each line of the header containing all residues
                    for jik=1:length(tline)
                        header=tline{jik};
                        % if dline(2) is equal to
                        if strcmp(dline{2},header)
                            matrix1(row,jik)=string((str2num(dline{3})/totalframes)*100);
                        end
                    end
                end
           elseif (length(dline) == 0)
                row=row+1;
           end
        end
    % now place matrix1 into another matrix
    matrix2(street,:)=matrix1(1,:);
    matrix3(street,:)=matrix1(2,:);
    matrix4(street,:)=matrix1(3,:);
    street=street + 1;
    end
    %now that I've gone through the filenames I need to get averages of the
    %columns of matrix2 3 4. (not necessary when there is only one file.
  %  matrix1 = zeros(3,length(tline));
  %  matrix1(1,:)=mean(matrix2,1);
  %  matrix1(2,:)=mean(matrix3,1);
  %  matrix1(3,:)=mean(matrix4,1);
  %  matrix5(1,:)=std(matrix2,0,1)/sqrt(3);
  %  matrix5(2,:)=std(matrix3,0,1)/sqrt(3);
  %  matrix5(3,:)=std(matrix4,0,1)/sqrt(3);
    %matrix5(1,:)=std(matrix2,0,1);
    %matrix5(2,:)=std(matrix3,0,1);
    %matrix5(3,:)=std(matrix4,0,1);
    figure
    hold on
    %title(clustername) 
    % frame0
   % xvalues={'PHE-160'	'SER-161'	'TYR-189'	'TYR-190'	'LEU-192'	'ASP-224'	'SER-225'	'PHE-231'	'ASP-232' 'SER-121`'	'TYR-122`'	'SER-123`'	'SER-213`'	'ARG-214`'	'ASN-215`'	'ARG-216`'	'ASP-217`'	'ALA-218`'	'GLU-220`' 'MG-2001'};
    % No Filter
    xvalues={'TYR-155'	'VAL-156'	'ASN-158'	'ASP-159'	'PHE-160'	'SER-161'	'TRP-162'	'ASP-163'	'ARG-165'	'TYR-166'	'TYR-189'	'TYR-190'	'PHE-191'	'LEU-192'	'ASP-224'	'SER-225'	'SER-226'	'ASN-227'	'TYR-230'	'PHE-231'	'ASP-232' 'ASP-119`'	'LEU-120`'	'SER-121`'	'TYR-122`'	'SER-123`'	'MET-124`'	'VAL-157`'	'TYR-166`'	'CYS-177`'	'MET-180`'	'SER-213`'	'ARG-214`'	'ASN-215`'	'ARG-216`'	'ASP-217`'	'ALA-218`'	'PRO-219`'	'GLU-220`'	'THR-250`'	'ASP-251`'	'ALA-252`' 'MG-2001'};
    % 10% Filter
   % xvalues={'ASP-159'	'PHE-160'	'SER-161'	'ASP-163'	'TYR-189'	'TYR-190'	'LEU-192'	'ASP-224'	'SER-225'	'PHE-231' 'ASP-119`'	'LEU-120`'	'SER-121`'	'TYR-122`'	'SER-123`'	'TYR-166`'	'SER-213`'	'ARG-214`'	'ASN-215`'	'ARG-216`'	'ASP-217`'	'ALA-218`'	'GLU-220`'	'THR-250`'	'ASP-251`'	'ALA-252`' 'MG-2001'};
    xvalues=reordercats(categorical(xvalues),xvalues);
    f=bar(xvalues,matrix1);
    colororder("default")
    %errorbar(xvalues,matrix1,matrix5,matrix5)
%    b=bar(xvalues,matrix1);
%    % Calculate the number of groups and number of bars in each group
%    [ngroups,nbars] = size(matrix1);
%    % Get the x coordinate of the bars
%    x = nan(nbars, ngroups);
%    for i = 1:nbars
%        x(i,:) = b(i).XEndPoints;
%    end
%    % Plot the errorbars
%    errorbar(x',matrix1,matrix5,'k','linestyle','none');
   % if strcmp(conformations{k}, "1.bent35A\cluster")
        legend("R","G","D")
   %     legend boxoff
   % end
    ylim([0 103])
    ylabel('bound contact time (% frames)','FontSize',20)
    fontsize(gcf,scale=1.65);
    set(gca,'XTickLabelRotation',90)
    set(gcf,'Position',[100 100 600 500])
    hold off
end
%print(outputfig,'-vector','-dpng')
%print('OpenallBoundFrames','-vector','-dpng')
%%
        %startPos=wildcardPattern + "-A";
        %endPos=" " + wildcardPattern
        %xvalues2=eraseBetween(tline(:,:),startPos,endPos,'Boundaries','exclusive');
        %xvalues=reordercats(categorical(tline),tline);
        %tline2=regexp(tline,'\w*-\w*','match');
        %tline3=[]
        %for nix=1:length(tline2)
        %    tline3=[tline3; tline2{nix}{1,1}]
        %end
        %tline3=cellstr(tline3)
