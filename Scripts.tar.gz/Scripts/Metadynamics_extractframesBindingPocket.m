clear
clc
close all

%Colvar_reweight might be better to use? 12/18
% reads the individual COLVAR files and extracts frame numbers based on the
% upper and lower thresholds below. All variables directly below need to be
% updated for your machine and file names you use. Also the lowerx, upperx,
% etc. need to be changed to match where your area of interest on the
% FES is.
root1="C:\Users\and_r\OneDrive - University of Utah\BidoneLab\integrin\funnel_metad\24march12\funnelMetad\";
%folders1 = ["1.bent35A\" "2.int135A\" "3.int235A\" "4.open35A\"] ;
folders1 = "bent_2\" ;
subfolders2 = ["0" "1" "2" "3" "4" "5" "6" "7" "8" "9" ];
%subfolders2 = ["0" "3" "6" "9" ];
%subfolders2 = "4";
outputname="bound1";

for l=1:length(folders1)
    if strcmp(folders1{l},"bent_2\") 
    %    binding pocket 1.
     %   lowerx = 0.813568 ;
     %   upperx = 1.0604 ;
     %   uppery = 0.52767 ;
     %   lowery = 0.17491 ;
        % binding pocket 2.
        lowerx = 1.4768; %nm
        upperx = 1.79464; %nm
        lowery = 0.0; %nm
        uppery = 0.52767;%nm
    elseif strcmp(folders1{l},"bent_4\") 
        % Bindind Energy = 0	-4.47527967630216
        % binding pocket.
        %yref=5.05; % Reference to unbound state on the y-axis
        lowerx = 1.48131 ;
        upperx = 1.69279 ;
        uppery = 0.306293 ;
        lowery = 0 ;
    elseif strcmp(folders1{l},"3.int235A\") 
        % binding Energy = 0	-12.7515786536631
        % binding pocket.
        %yref=4.15; % Reference to unbound state on the z-axis
        lowerx = 0.167; %nm
        upperx = 0.485; %nm
        lowery = 0.273; %nm
        uppery = 0.68;%nm
    elseif strcmp(folders1{l},"4.open35A\")  
        % Binding Energy = 0	-24.6826745936761
        % Binding Energy = 0	-23.5428913278863
        % binding pocket.
        %yref=4.42; % Reference to unbound state on the y-axis
        lowerx = 0.44; %nm
        upperx = 0.97; %nm
        lowery = 0.050; %nm
        uppery = 0.158;%nm
    end
    for m=1:length(subfolders2)
        y=strcat(root1,folders1{l},subfolders2{m});
        %y=strcat(root1,folders1{l});
        if isfolder(y) == 0
            fprintf('%2.0f doesnt exist. Skipping.\n',str2num(subfolders2{m}))
            continue;
        end
        cd(y); %move to directory    
        fid2 = fopen('COLVARs','rt'); % Open the file
        colvardata = textscan(fid2,'%f %f %f %*s %*s %*s %*s %*s %*s %*s %*s %*s','CommentStyle','#!');
        fid2=fclose(fid2);
        cellread = cell2mat(colvardata);
        % make 2 matrices of indexes that meet the criteria for inclusion in
        % each dimension
        % make sure the indexing for cellread is correct
        xindex=find(cellread(:,3) <= upperx & cellread(:,3) >= lowerx) ; 
        yindex=find(cellread(:,2) <= uppery & cellread(:,2) >= lowery);
        % compare both x and y dimension indices to each other and extract only
        % the indices that are in both matrices
        [Lia,Locb]=ismember(xindex,yindex); %gives new indices for reference to yindex where x and y indices overlap
        xyindex =nonzeros(Locb); % remove zeros from the comparison
        indexforframes = yindex(xyindex); % extract the original index numbers so we can go back to original data
        timestamp=cellread(indexforframes,1);
        % converting the timestamp to framenumber
        framenum=timestamp;
        % deleting all framenumbers that are not whole numbers
        framenum(fix(framenum)~=framenum) = [];
        % deleting all duplicate framenumbers
        framenum=unique(framenum,'last');
        outs=strcat(outputname,".txt");
        writematrix(framenum,outs);
    end
end


