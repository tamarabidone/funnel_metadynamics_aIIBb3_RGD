% Note: this plots only 1 walker and the distance of Met-335-O from
% 2vdr(closed) and 3t3p(open) structures
% the correlated movement appears to be due to Beta-I domain rotation when
% visually inspected. The anticorrelated movement is what is expected. As
% we move farther from closed we should move closer to open conformation.

% Note: it might be worthwhile to calculate the difference between the distances from 2vdr and 3t3p. 
% eg. (from2vdr) - (from3t3p) 5=closed 0=middle -5=open 

% allocate resources
% ml matlab/R2023a
% matlab -nodisplay
% copy the below script into the chpc terminal and hit enter
clear
clc
close all

% working on finding the weighted average slope of the fit lines.
% weight = walkersimtime/totalsimtime
openfile = "DistanceAlpha7"; % "SASA_BetaI" "SASA_BetaPro" "SASA_RGD"

root1="C:\Users\and_r\OneDrive - University of Utah\BidoneLab\integrin\funnel_metad\24march12\Equilibrium\";
replicas=["bent" "bent_2" "bent_3"];
replica=[];
datareplica=[];
SEM=[];
ts=[];
CI=[];
CI2=[];
for xy=1:length(replicas)
    yall=strcat(root1,replicas(xy));
    cd(yall); %move to directory
    dirname=pwd ; % use the current directory to name the figures
    figname=regexp(dirname,'\','split'); %split the directory path based on \
    figtitle2=strcat(figname(9),'_',figname(10));  
    dataincr = {};
    slope=[];
    time=[];
    time=15000;
    fullFilename = fullfile(strcat(openfile,'.dat')); %for Equilibrium
    dataall = readmatrix(fullFilename);
    replica(:,xy)=(dataall(:,2)-dataall(:,3));
end
[rownum,colnum]=size(replica);
datareplica=mean(replica,2);
SEM = std(replica,0,2)/sqrt(colnum);
ts = tinv([0.025 0.975],colnum-1);
CI = datareplica + ts.*SEM;
CI2=(CI(:,2)-CI(:,1))./2;
% this is plotting the difference in measures on one line.
figure('Name',char(figtitle2))
hold on
plot(round((dataall(1:10:time,1)*10/1000),0),datareplica(1:10:time,1),'b-')
%errorbar(round(dataall(1:500:time,1)*10/1000),datareplica(1:500:time,1),CI2(1:500:time,1))
Ang= char(197);
ylabel(strcat('{\alpha7} COM Distance',' (',Ang,')'),'fontsize', 10);
xlabel('Time (ns)','fontsize', 10);
ylim([-5,5])
%xlim([0,150])
set(gcf, 'Units', 'Inches', 'Position', [1, 1, 1.75, 2])
set(gcf,'PaperPositionMode','auto')
%leg = legend({'from 2vdr (open)','from 3t3p (closed)'},'Position',[0.05 0.74 1.1 0.2],'units','inches','fontsize', 7.5);
%legend('boxoff')
%leg.ItemTokenSize = [6,10];
hold off
%walkername = fullfile(strcat('/uufs/chpc.utah.edu/common/home/bidone-group3/robert/1_HeadpieceTest/alpha7/test/',openfile,char(figtitle2)));
%print(walkername{1},'-r600','-dpng')

%% this is plotting both measures on the same graph.
figure('Name',char(figtitle2))
hold on
plot(round((dataall(1:10:time,1)*10/1000),0),dataall(1:10:time,2),'b',round((dataall(1:10:time,1)*10/1000),0),dataall(1:10:time,3),'r-')
Ang= char(197);
ylabel(strcat('{\alpha7} COM Distance',' (',Ang,')'),'fontsize', 10);
xlabel('Time (ns)','fontsize', 10);
ylim([0,11])
%xlim([0,150])
set(gcf, 'Units', 'Inches', 'Position', [1, 1, 1.75, 2])
set(gcf,'PaperPositionMode','auto')
leg = legend({'from 2vdr (open)','from 3t3p (closed)'},'Position',[0.05 0.74 1.1 0.2],'units','inches','fontsize', 7.5);
legend('boxoff')
leg.ItemTokenSize = [6,10];
hold off
walkername = fullfile(strcat('/uufs/chpc.utah.edu/common/home/bidone-group3/robert/1_HeadpieceTest/alpha7/test/',openfile,char(figtitle2)));
print(walkername{1},'-r600','-dpng')






%%

ylimits = [-0.5 48]; % BetaPro [167 212] (45) BetaI [87 132] (45) RGD [0 11] (11)
walkerYlimits = [0,50];


    plot(cell2mat(dataincr{1,1}),cell2mat(dataincr{1,2}),'color','black')
    coefficients = polyfit(cell2mat(dataincr{1,1}),cell2mat(dataincr{1,2}),1);
    slope(1) = coefficients(1);
    xFit = linspace(min(cell2mat(dataincr{1,1})), max(cell2mat(dataincr{1,1})), 1000) ;
    yFit = polyval(coefficients , xFit);
    plot(xFit, yFit, 'r-');
    limlength = dataincr{1,1};
    lim=limlength{end};
    plot([lim,lim],walkerYlimits,'--','color','black')
    time(1) = length(dataincr{1,1});
    for jik=2:length(subfolders2)
       if isfolder(subfolders2{jik}) == 0
            fprintf('%2.0f doesnt exist. Skipping.\n',str2num(subfolders2{jik}))
            continue;
        end
        plot((cell2mat(dataincr{jik,1}))+lim,cell2mat(dataincr{jik,2}),'color','black')
        coefficients = polyfit(cell2mat(dataincr{jik,1}),cell2mat(dataincr{jik,2}),1);
        slope(jik) = coefficients(1);
        xFit = linspace(min(cell2mat(dataincr{jik,1})), max(cell2mat(dataincr{jik,1})), 100) ;
        yFit = polyval(coefficients , xFit);
        plot(xFit+lim, yFit, 'r-');    
        limlength = dataincr{jik,1};
        lim=lim+(limlength{end});
        time(jik) = length(dataincr{jik,1});
        plot([lim,lim],walkerYlimits,'--','color','black')
    end
    totaltime = sum(time);
    weights = time/totaltime ;
    averageslope = sum(slope .* weights);
    set(gca,'box','off');
    ylabel('Distance (Å)');
    xlabel('Time (ns)');
    xlim([0 2300])
    ylim(ylimits); 
    set(gcf, 'Units', 'Inches', 'Position', [1, 1, 1.75, 2])
    set(gcf,'PaperPositionMode','auto')
    %if strcmp(folders1(k),"1.bent35A\")
    %    legend({"Walker 1", "RGD Bound", "RGD Unbound"},'Box','off','location','southeast');
    %end
    hold off
    walkername = fullfile(strcat('G:\My Drive\PaperFiguresV2\Figure6\',openfile,figtitle2(2)));
    print(walkername{1},'-r600','-dpng')
    fprintf(fid2,'%s',figtitle2{2},' ');
    fprintf(fid2,'%.4f\n',averageslope);
%end
fclose(fid2);
